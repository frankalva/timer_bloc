part of 'timer_bloc.dart';
// Definimos nuestro timer state, creamos nuestra clase de cada uno
// en este caso el los estados para cada uno, cuando el timer inicia
// cuando el timer esta en pausa, cuando el timer esta en progreso
// cuando el timer termina.
sealed class TimerState extends Equatable {
  const TimerState(this.count);
  final int count;
  
  @override
  List<Object> get props => [count];
}

final class TimerInitial extends TimerState {
  TimerInitial(super.count);

  @override
  String toString() => 'TimerInitial {duration : $count}'; // es igual a un return
}


final class TimerRunPause extends TimerState{
  TimerRunPause(super.count);

  @override
  String toString() => 'TimerRunPause { duration: $count}';
}



final class TimerRunInProgress extends TimerState{
  TimerRunInProgress(super.count);

  @override
  String toString() => 'TimerRunInProgress { duration: $count}';
}


final class TimerRunComplete extends TimerState{
  const TimerRunComplete(): super(0);
}
