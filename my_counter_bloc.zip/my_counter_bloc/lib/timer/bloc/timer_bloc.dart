import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:my_counter_bloc/ticker.dart';

part 'timer_event.dart';
part 'timer_state.dart';

class TimerBloc extends Bloc<TimerEvent, TimerState> {
  static const int _duration = 60; //inicializamos el contador en 60 seg
  final Ticker _ticker;
 
  StreamSubscription<int>? _ticketSubscription;

  TimerBloc({required Ticker ticker}) : _ticker = ticker ,super(TimerInitial(_duration)) {
  on<TimerStarted>(_onStarted);
  on<_TimerTicked>(_onTicked);
  on<TimerPaused>(_onPaused);
  on<TimerResumed>(_onResumed);
  on<TimerReset>(_onReset);
  }

  @override
  Future<void> close(){
    _ticketSubscription?.cancel();
    return super.close();
  }

  void _onReset(TimerReset event, Emitter<TimerState> emit){
    _ticketSubscription?.cancel();
    emit(TimerInitial(_duration));
  }

  void _onResumed(TimerResumed event, Emitter<TimerState> emit){
    if(state is TimerRunPause){
      _ticketSubscription?.resume();
      emit(TimerRunInProgress(state.count));
    }

  }

  void _onStarted(TimerStarted event, Emitter<TimerState> emit){
    emit(TimerRunInProgress(event.count));
    _ticketSubscription?.cancel();
    _ticketSubscription = _ticker
            .tick(ticks: event.count)
            .listen((count) => add(_TimerTicked(count: count)));
  }


  void _onTicked(_TimerTicked event, Emitter<TimerState> emit){
      emit(event.count > 0
            ? TimerRunInProgress(event.count)
            : TimerRunComplete(),
      );
  }

  void _onPaused(TimerPaused event, Emitter<TimerState> emit){
    if(state is TimerRunInProgress){
      _ticketSubscription?.pause();
      emit(TimerRunPause(state.count));
    }
  }

}
