import 'package:flutter/material.dart';
import 'package:my_counter_bloc/app.dart';

void main() {
  runApp(const MyApp());
}




