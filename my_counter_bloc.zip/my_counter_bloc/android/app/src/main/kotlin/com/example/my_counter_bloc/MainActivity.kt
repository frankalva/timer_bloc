package com.example.my_counter_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
